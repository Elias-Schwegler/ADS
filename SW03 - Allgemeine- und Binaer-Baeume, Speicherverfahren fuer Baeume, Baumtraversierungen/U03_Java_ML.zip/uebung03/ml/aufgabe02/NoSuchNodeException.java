/*
 * HSLU / ICS/AIML : Modul ADS : Algorithmen & Datenstrukturen
 * Version: Sun Mar  1 18:04:18 CET 2026
 */

package uebung03.ml.aufgabe02;

/**
 * Thrown if a reference to a node (parent or child) is given which is not part
 * of the tree.
 */
public class NoSuchNodeException extends Exception {

  private static final long serialVersionUID = 1L;

}
 
