/*
 * HSLU / ICS/AIML : Modul ADS : Algorithmen & Datenstrukturen
 * Version: Sun Mar  1 18:04:18 CET 2026
 */

package uebung03.ml.aufgabe02;

import java.util.ArrayList;

public class VectorTree<T> implements TreeInterface<T> {
  
  private final static int ROOT_INDEX = 1;

  enum ChildSide {
    LEFT, RIGHT
  }

  protected ArrayList<T> binaryTree;
  protected int size;

  public VectorTree() {
    binaryTree = new ArrayList<>();
    binaryTree.add(0, null);
    binaryTree.add(ROOT_INDEX, null);
  }

  @Override
  public T root() {
    return binaryTree.get(ROOT_INDEX);
  }

  @Override
  public void setRoot(T root) {
    if (root() != null) {
      remove(ROOT_INDEX);
    }
    binaryTree.set(ROOT_INDEX, root);
    size = 1;
  }

  @Override
  public T parent(T child) throws NoSuchNodeException {
    if (isRoot(child)) {
      return null; // this object is the root... thus no parent...
    }
    return binaryTree.get(position(child) / 2);
  }

  @Override
  public T leftChild(T parent) throws NoSuchNodeException {
    return getChild(parent, ChildSide.LEFT);
  }

  @Override
  public T rightChild(T parent) throws NoSuchNodeException {
    return getChild(parent, ChildSide.RIGHT);
  }

  protected T getChild(T parent, ChildSide childSide) throws NoSuchNodeException {
    int childPos = childPos(parent, childSide);
    if (!hasNodeAtPosition(childPos)) {
      return null;
    } 
    return binaryTree.get(childPos);
  }

  protected int childPos(T parent, ChildSide childSide)
      throws NoSuchNodeException {
    return childPos(position(parent), childSide);
  }
    
  protected static int childPos(int parentPos, ChildSide childSide) {
    return parentPos * 2 + (childSide == ChildSide.LEFT ? 0 : 1);
  }

  @Override
  public boolean isInternal(T node) throws NoSuchNodeException {
    return !isExternal(node);
  }

  @Override
  public boolean isExternal(T node) throws NoSuchNodeException {
    int leftChildPos = childPos(node, ChildSide.LEFT);
    int rightChildPos = leftChildPos + 1;
    boolean result;
    if (hasNodeAtPosition(leftChildPos) || hasNodeAtPosition(rightChildPos)) {
      result =  false;
    } else {
      result =  true;
    }
    return result;
  }

  protected boolean hasNodeAtPosition(int pos) {
    if (pos > binaryTree.size() - 1) {
      return false;
    }
    return binaryTree.get(pos) != null;
  }

  @Override
  public boolean isRoot(T node) {
    return node.equals(binaryTree.get(ROOT_INDEX));
  }

  @Override
  public void setRightChild(T parent, T child) throws NoSuchNodeException {
    setChild(parent, child, ChildSide.RIGHT);
  }

  @Override
  public void setLeftChild(T parent, T child) throws NoSuchNodeException {
    setChild(parent, child, ChildSide.LEFT);
  }

  protected void setChild(T parent, T child, ChildSide childSide)
      throws NoSuchNodeException {
    removeChild(parent, childSide);
    int childPos = childPos(parent, childSide);
    assureSize(childPos);
    if (binaryTree.set(childPos, child) == null) {
      size++;
    }
  }

  @Override
  public void removeRightChild(T parent) throws NoSuchNodeException {
    removeChild(parent, ChildSide.RIGHT);
  }

  @Override
  public void removeLeftChild(T parent) throws NoSuchNodeException {
    removeChild(parent, ChildSide.LEFT);
  }
  
    
  protected void removeChild(T parent, ChildSide childSide)
      throws NoSuchNodeException {
    int childPos = childPos(parent, childSide);
    if (hasNodeAtPosition(childPos)) {
      remove(childPos);
    }
  }

  /**
   * Precondition: Node exists.
   */
  protected void remove(int nodePos) {
    for (ChildSide childSide : ChildSide.values()) {
      int childPos = -1;
      childPos = childPos(nodePos, childSide);
      if (hasNodeAtPosition(childPos)) {
        remove(childPos);
      }
    }
    binaryTree.set(nodePos, null);
    size--;
  }

  @Override
  public int size() {
    return size;
  }
  
  protected int position(T node) throws NoSuchNodeException {
    int pos = binaryTree.indexOf(node);
    if (pos == -1) {
      throw new NoSuchNodeException();
    }
    return pos;
  }

  protected void assureSize(int pos) {
    int currentLength = binaryTree.size();
    if (pos >= currentLength) {
      int newLength = 2 * currentLength;
      for (int i = currentLength; i < newLength; i++) {
        binaryTree.add(null);
      }
    }
  }

  public void printVector(String message) {
    System.out.println("\n" + message);
    System.out.println(binaryTree);
  }

}
