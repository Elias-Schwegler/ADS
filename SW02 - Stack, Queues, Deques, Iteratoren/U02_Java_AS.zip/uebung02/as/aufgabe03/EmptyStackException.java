/*
 * HSLU / ICS/AIML : Modul ADS : Algorithmen & Datenstrukturen
 * Version: Sat Feb 21 16:08:38 CET 2026
 */

package uebung02.as.aufgabe03;

/**
 * Runtime exception thrown when one tries to perform operation top or pop on an
 * empty stack.
 */

public class EmptyStackException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public EmptyStackException(String err) {
    super(err);
  }
}
 
 
 
